<?php

    $conn=mysqli_connect('localhost','id13614457_root','z<DiFL\4Fo/uIs)W','id13614457_cs');
   
    if(!$conn)
    {
        die(' Please Check Your Connection'.mysqli_error($conn));
    }
?>