
<!DOCTYPE html>
<html>
<head>
  <title>Signup Form</title>
</head>
<body>
<center>
<h2>Signup Form</h2>
<form method="post" action="connect.php">
    
<table class="" cellpadding="10">
    <tr>
        <td>Full Name</td>
        <td><input type="text" class="" name="fullname" required></td>
    </tr>
    <tr>
        <td>Email</td>
        <td><input type="email"  class="" name="email" required></td>
    </tr>
    <tr>
        <td>Mobile Number</td>
        <td><input type="text"  class=""name="mobile_number" required></td>
    </tr>
    <tr>
        <td>Class</td>
        <td><input type="number"  class="" name="class" required></td>
    </tr>
    <tr>
        <td>Password</td>
        <td><input type="text"  class="" name="password" required></td>
    </tr>

</table>
 <input type="submit" class="" value="Sign Up ">

    
</form>
</center>
</body>
</html>