<?php
	include'connection.php';
	$fullname = $_POST['fullname'];
	$email=$_POST['email'];
	$mobile_number =$_POST['mobile_number'];
	$class= $_POST['class'];
	$password = $_POST['password'];

	mysqli_query($conn,"insert into users (fullname,email,mobile_number,class,password)values ('$fullname','$email', '$mobile_number','$class','$password')");
	
	//sending email to user
	$to_user = $email;
	$subject_to_user = "MissionED Signup Form";
	$message_to_user = "
				<html>
				<head>
				<title>MissionED Signup Form</title>
				</head>
				<body>
				<h2>MissionED Signup Form</h2>
				<p>Your Account:</p>
				<p>Full Name : ".$fullname."</p>
				<p>Email: ".$email."</p>
				<p>Mobile No: ".$mobile_number."</p>
				<p>Class : ".$class."</p>
				<p>Password: ".$password."</p>
				<p>Your Message Or Payment Status</p>
				</body>
				</html>
				";
			
		$headers = "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$headers .= "From: aryansn0101@gmail.com". "\r\n" .

		mail($to_user,$subject_to_user,$message_to_user,$headers);


//sending email to admin
	$to_admin = "aryansn0101@gmail.com";
	$subject_to_admin = "MissionED Signup Form";
	$message_to_admin = "
				<html>
				<head>
				<title>MissionED Signup Form</title>
				</head>
				<body>
				<h2>MissionED Signup Form</h2>
				<p>Your Account:</p>
				<p>Full Name : ".$fullname."</p>
				<p>Email: ".$email."</p>
				<p>Mobile No: ".$mobile_number."</p>
				<p>Class : ".$class."</p>
				<p>Password: ".$password."</p>
				<p>Click To give Access</p>
				</body>
				</html>
				";
			
		$headers = "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$headers .= "From: aryansn0101@gmail.com". "\r\n" .


		mail($to_admin,$subject_to_admin,$message_to_admin,$headers);

		echo "Mail Sent";
  		
	
?>